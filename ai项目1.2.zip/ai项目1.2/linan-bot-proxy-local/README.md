# 本地代理服务器

## 启动步骤

1. 确保已安装 Node.js（https://nodejs.org）
2. 在此文件夹打开终端
3. 运行：npm install
4. 运行：npm start
5. 看到 "✅ 代理服务器已启动" 说明成功

## 前端配置

把前端 HTML 里的 PROXY_URL 改成：
http://localhost:3000/api/chat
